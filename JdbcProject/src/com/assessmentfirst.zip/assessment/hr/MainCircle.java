package com.assessment.hr;

import java.util.ArrayList;

public class MainCircle {

	public static void main(String[] args) {
	int [] arr = new int [100];
	int a= (int) Math.random();
	int total=0;
	for(int i=a ;i<arr.length;i++) 
	{
		Circle obj;
		obj = new CirclrTest(i);
		obj.getArea();
		total +=obj.sum;
		obj.printinfo();
	}
	
	System.out.println("Tota of 100 Circles = "+total);
	
	
		
		
	}

}
