package com.assessment.hr;

public abstract class Rectangle {
	
	abstract void area();
	
	 void Rectangle() {
		 System.out.println("rectangle called");
	 }
	
	

}
