package com.assessment.hr;

public interface ShapeBehaviour {
	
	double getArea();

	void printInfo();

}
