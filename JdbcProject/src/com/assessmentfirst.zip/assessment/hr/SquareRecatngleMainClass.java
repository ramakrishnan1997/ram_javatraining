package com.assessment.hr;

public class SquareRecatngleMainClass {

	public static void main(String[] args) {
		Rectangle obj;
		obj =new Square();
		obj.area();

	}

}
