package com.assessment.hr;

public class CirclrTest extends Circle{
	
	int radi;
	
	public CirclrTest(int radius) {
		super(radius);
	}
	public static void main(String[] args) {
		Circle obj;
		obj = new CirclrTest(2);
		obj.getArea();
		obj.printinfo();
	
	}
	
}
