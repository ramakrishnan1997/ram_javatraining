package com.assessment.hr;

public class Cir extends Shape{

	

	@Override
	public void printInfo() {
		
		System.out.println("circle called");
		
	}

	@Override
	public double getArea() {
	
		
		return 0;
	}

}
