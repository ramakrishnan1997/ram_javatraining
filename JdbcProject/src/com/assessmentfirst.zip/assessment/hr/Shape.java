package com.assessment.hr;

public abstract class Shape implements ShapeBehaviour{

	
}
