package com.assessment.hr;

public class ShapeMain {

	public static void main(String[] args) {
		
		Shape obj;
		obj=new Reactangle();
		obj.printInfo();
		obj=new Triangle();
		obj.printInfo();
		obj=new Cir();
		obj.printInfo();

	}

}
