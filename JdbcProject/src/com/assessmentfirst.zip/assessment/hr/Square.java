package com.assessment.hr;

public  class Square extends  Rectangle{

	@Override
	void area() {
		System.out.println("square called");
		super.Rectangle();
	}

	

	

	



	
	

}
