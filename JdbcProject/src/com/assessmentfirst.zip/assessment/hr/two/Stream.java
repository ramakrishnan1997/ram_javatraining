package com.assessment.hr.two;

import java.io.*;


public class Stream {

	public static void main(String[] args) throws IOException {
		
		String name="/home/vastpro/newdir/logo.png";
		FileInputStream f=new FileInputStream(name);
		BufferedInputStream bi =new BufferedInputStream(f);
		int i ;
		while((i=bi.read())!=-1) {
			FileOutputStream o=new FileOutputStream("demo/logo.png");
			BufferedOutputStream oi =new BufferedOutputStream(o);
			oi.write(i);
			System.out.println("succes");
		}
		
		
		
		
		
				
		

	}

}
