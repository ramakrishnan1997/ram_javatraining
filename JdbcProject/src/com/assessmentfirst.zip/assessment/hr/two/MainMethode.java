package com.assessment.hr.two;

import java.util.Date;

public class MainMethode {

	public static void main(String[] args) {
		Date a = new Date();

		Car ab = new Car(1244, "hatchback", a);

		System.out.println(ab.equals(ab));

		System.out.println(ab.toString());

		System.out.println(ab.hashCode());

	}

}
