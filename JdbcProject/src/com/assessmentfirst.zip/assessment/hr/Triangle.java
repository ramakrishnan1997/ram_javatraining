package com.assessment.hr;

public class Triangle extends Shape{

	@Override
	public double getArea() {
		
		return 0;
	}

	@Override
	public void printInfo() {
		
		System.out.println("Triangle called");
		
	}

}
